<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Logged extends CI_Controller {


	 function __construct(){
	 	parent::__construct();
		$this->load->model('Loggedin');$this->load->library('session');		$this->load->helper('url');
		$this->load->model('Admin_model');

	}
	public function register()
	{ 
	$this->load->view('register');
 	}
	public function registerform()
	{ 
	    $data['name'] = $this->input->post('name');
		$data['email'] = $this->input->post('email');		
		  $data['gender'] = $this->input->post('gender');	
		 
		$pwd = $this->input->post('pwd');
		$data['pwd'] = $this->input->post('pwd');	
		$data['password'] = hash("sha256",$pwd);		
		   $data['pic'] =$image = time().'-'.$_FILES["pic"]['name'];

			$config = array(
			'upload_path' => realpath(APPPATH . '../assets/image/'),
			'allowed_types' => "gif|jpg|png|jpeg|JPEG|JPG|PNG|GIF",
			'overwrite' => TRUE, 
			'file_name' => $image
			);
			$this->load->library('upload', $config); 	
			$this->upload->initialize($config);

			 echo $config['upload_path']; 
			if($this->upload->do_upload('pic'))
			{
				
				$data = $this->Admin_model->add_with_check($data,'register',['email' =>$data['email']]);

  			}
			else
			{
				 $error = array('error' => $this->upload->display_errors());
			     $data['resultmsg']=$error['error'];
			}
        $this->session->set_flashdata('message', $data['resultmsg']);
		redirect('logged/register');		
  	}
	public function in()
	{   
		if (($this->session->userdata('userlogged') == true )){ 
			redirect('logged/out/in');
		   	exit;
		}
		if(isset($_POST['logged_in'])){  
			$data['email'] = $this->input->post('email');
			$data['password'] = $this->input->post('pwd');
			$table = "register";
			if(isset($_POST['logged_in']) && ($data['email']!='') && ($data['password'] !='')) {
				$data = $this->Loggedin->validateadmin($data,$table);
				if($data==true) {
					redirect('home/dashboard');
				}
			}
			else{	 
				$this->session->set_flashdata('error_message', '<h4 class="alert_error">The email or password is incorrect</h4>');
			}
			redirect('logged/in');
	   	}
		$this->load->view('login');
	}
	function out($go='in') {

		$this->session->sess_destroy();

		session_destroy();

		redirect('logged/'.$go);

	}
}
