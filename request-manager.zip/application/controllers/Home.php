<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

  public function __construct(){
        parent::__construct();
		$this->load->helper('url');
		
		$data[]=array();		 
		$this->load->library('session');
		$this->load->library('form_validation');
		$this->load->library('upload');
		$this->load->model('Admin_model');
     
     $this->validate();

      }
	  
	 function validate() {
		if (($this->session->userdata('userlogged') !== true ) ){
			redirect(base_url().'logged/out');
			exit;
		}
		return true;
	}
	public function register()
	{ 
	$this->load->view('register');
 	}
	public function editprofilesubmit()
	{
		$mid = $this->input->post('id');
		$data['name'] = $this->input->post('name');
		$data['email'] = $this->input->post('email');		
		$data['gender'] = $this->input->post('gender');	
		$pwd = $this->input->post('pwd');
		$data['pwd'] = $this->input->post('pwd');
$data['password'] = hash("sha256",$pwd);			
		 $pictur =$_FILES["pic"]['name'];
		 if($pictur!=''){
			
		   $data['pic'] =$image = time().'-'.$_FILES["pic"]['name'];

			$config = array(
			'upload_path' => realpath(APPPATH . '../assets/image/'),
			'allowed_types' => "gif|jpg|png|jpeg|JPEG|JPG|PNG|GIF",
			'overwrite' => TRUE, 
			'file_name' => $image
			);
			$this->load->library('upload', $config); 	
			$this->upload->initialize($config);

			 echo $config['upload_path']; 
			if($this->upload->do_upload('pic'))
			{
				
				$data = $this->Admin_model->edit_data($data,'register',['id'=>$mid]);

  			}
			else
			{
				 $error = array('error' => $this->upload->display_errors());
			     $data['resultmsg']=$error['error'];
			}
		 }
		 else{
			 		$data['pic'] = $this->input->post('oldpic');

			 				$data = $this->Admin_model->edit_data($data,'register',['id'=>$mid]);

		 }
        $this->session->set_flashdata('message', $data['resultmsg']);
		redirect('home/editprofile');		
		
	}
		
		
	public function editprofile()
	{	
		$mid = $this->session->userdata('user_id');
		$where = ['id'=>$mid];
		$field = ['*'];
		$data['res'] = $this->Admin_model->get_where_from($where,'register',$field);
		$this->load->view("editprofile",$data);
	}
	public function dashboard()
	{
		
		$this->load->view("dashboard");
	}
	public function friendlist()
	{	 	$mid = $this->session->userdata('user_id');
	
		 $data['res'] = $this->Admin_model->jointable($mid); //echo $this->db-last_query();exit;
		$this->load->view("friendslist",$data);
	}
	public function userlist()
	{	$id = $this->session->userdata('user_id');
 		$where = [];
		$field = ['id','name','email','pic','gender'];
		$data['res'] = $this->Admin_model->get_where_from($where,'register',$field);
		$friendslist=$this->Admin_model->get_all_data('friendslist');
 		foreach($friendslist as $key => $value) {
		}
		//$dataa[$myid][$row->id] = $value->sender_id; 
		$this->load->view("userlist",$data);
	}
	public function actionhandler()
	{//echo"Sdf";exit;
		$data['sender_id']= $this->session->userdata('user_id');
		$data['receiver_id']=$this->input->post('id');
	 	$status=$this->input->post('status');
		
		
		if($status==0)
		{$data['status']=1;
			$data = $this->Admin_model->add_with_check($data,'friendslist',['sender_id' =>$data['sender_id'],'receiver_id' =>$data['receiver_id']]);
			$msg='Cancel Request';
		} elseif($status==1)
		{
			$data = $this->Admin_model->delete_id_table('friendslist',['sender_id' =>$data['sender_id'],'receiver_id' =>$data['receiver_id']]);
				$msg='Add Friend';
		}elseif($status==2)
		{
		 //echo $data['sender_id'];exit;
			$data['status']=3;
			
			
			  $data = $this->Admin_model->edit_data($data,'friendslist',['sender_id' =>$data['receiver_id'],'receiver_id' =>$data['sender_id']]);
 
 				$msg='Unfriend';
		}elseif($status==3)
		{
			$data = $this->Admin_model->delete_id_table('friendslist',['sender_id' =>$data['sender_id'],'receiver_id' =>$data['receiver_id']]);
				$msg='Add Friend';
		}

echo $msg;


	}
	
	/*
	
	public function signup()
	{
		$this->load->view("form");
	}
	public function register()
	{
		
		$data['name'] = $this->input->post('name');
		$data['email'] = $this->input->post('email');
		$data['pic'] = $this->input->post('pic');
		$data['gender'] = $this->input->post('gender');	
		$pwd = $this->input->post('pwd');
		$data['password'] = hash("sha256",$pwd);

 		$data = $this->Admin_model->add_with_check($data,'register',['email' =>$data['email']]);
		
						$this->session->set_userdata('message', $data['resultmsg']);
		redirect('home/signup');		

 	}
	
 
	public function form()
	{
	$this->load->view("form");
	}*/
}
