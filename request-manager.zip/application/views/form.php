<!DOCTYPE html>
<html lang="en">
  <head>
 
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/main.css">
    <!-- Font-icon css-->
   </head>
  <body class="app sidebar-mini">
    
  
    <main style="allign:center">       
      <div class="app-title">
        
      
      </div>
      <div class="row">  
        <div class="col-md-6">
          <div class="tile"> <a href="<?php  echo base_url();?>logged/in ">  <h3 class="tile-title">Login</h3> </a>

           <h3 class="tile-title">Register</h3>  
            <div class="tile-body">
			<?php if($this->session->userdata('message')!='') { echo  $this->session->userdata('message'); $this->session->unset_userdata('message');}?>
              <form method="post" action="<?php echo base_url();?>home/register" onsubmit="return checkPass()" >
                <div class="form-group">
                  <label class="control-label">Name</label>
                  <input class="form-control" type="text" name="name" required>
                </div>
                <div class="form-group">
                  <label class="control-label">Email</label>
                  <input class="form-control" type="email"name="email"required>
                </div>
                 <div class="form-group">
                  <label class="control-label">Phone</label>
                  <input class="form-control" type="text" name="phone"required>
                </div>
				 <div class="form-group">
                  <label class="control-label">Username</label>
                  <input class="form-control" type="text" name="username"required>
                </div>
				 <div class="form-group">
                  <label class="control-label">Password</label>
                  <input class="form-control" type="text"name="password"id="password"required >
                </div>
                
               
                 
                </div>
            
            </div>
            <div class="tile-footer">
              <button class="btn btn-primary" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Register</button> 
            </div>
          </div>
        </div>
   </form>
        <div class="clearix"></div>
       
        
      </div>
    </main>
   <script>
   function checkPass()
{  
	    var pwd = document.getElementById('password');
	 if(pwd.value.length < 9)
    {
      alert("password min 8 char required"); return false;

    }
} </script>
  </body>
</html>