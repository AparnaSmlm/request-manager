<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="<?php echo base_url()?>assets/css/style.css"> 
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
<?php  $this->view("sidebar");?>

<div id="main">
  <!--<h2>User Panel</h2>-->
   <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; </span>
   
  
  <h2>Friends List</h2>

<table>
 
	   
	   <tr>
    <th>Name</th>
    <th>Email</th>
    <th>Gender</th>
   </tr>
   <?php //print_r($res); 
   foreach($res as $rows) {
 $query=$this->db->query(" select * from register where id=$rows");
if($query->num_rows()!=0){
   foreach($query->result() as $row){
     
	   ?>
  <tr>
     <td><img src="<?php echo base_url();?>assets/image/<?php echo $row->pic;?>" width="50" height="50" /> <?php echo $row->name;?></td>
    <td><?php echo $row->email;?></td>
    <td><?php echo $row->gender;?></td>
	 
   
  </tr>
<?php }}} ?>
</table>
</div>

<script>
 
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
}
</script>
   
</body>
</html> 
