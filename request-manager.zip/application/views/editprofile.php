<style>.container {
  width: 500px;
 }

.container input {
  width: 100%;
  height:5%
 }
</style>
<html>

<head>
  <title>Edit</title>
</head>

<body>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="<?php echo base_url()?>assets/css/style.css"> 
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
<?php  $this->view("sidebar");?>

<div id="main">
  <!--<h2>User Panel</h2>-->
   <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; </span>
   
  
<h2>Edit Profile</h2><br>
<?php if($this->session->flashdata('message')!='') {echo $this->session->flashdata('message');}?>
<div class="container">
<?php
foreach($res->result() as $row) ?>
<form method="post" action="<?php echo base_url();?>home/editprofilesubmit" enctype="multipart/form-data">
   <input type="text" name="id" hidden value="<?php echo $row->id;?>"  ><br>
 Name : <input type="text" name="name" value="<?php echo $row->name;?>" required ><br>
Email : <input type="text" name="email" readonly value="<?php echo $row->email;?>" required><br>
Profile pic : <input type="file" name="pic" value="<?php echo $row->pic;?>" ><img src="<?php echo base_url();?>assets/image/<?php echo $row->pic;?>" width="50" height="50" /><br>
  <input type="text" name="oldpic" hidden value="<?php echo $row->pic;?>" ><br>
Gender : <input type="text" name="gender" value="<?php echo $row->gender;?>" required><br>
Pwd : <input type="text" name="pwd" value="<?php echo $row->pwd;?>" required><br><br>
  <input type="submit" name="submit"><br>
  </form>
</div></div>

<script>

function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
}
</script>
   
</body>
</html> 

</body>

</html>