<style>.container {
  width: 500px;
 }

.container input {
  width: 100%;
    height:5%

 }
</style>
<html>

<head>
  <title>Register</title>
</head>

<body>


<h2>Login</h2><br>
<?php if($this->session->flashdata('error_message')!='') {echo $this->session->flashdata('error_message');}?>
<div class="container">
<form method="post" action="<?php echo base_url();?>logged/in"  >
 Email : <input type="email" name="email" required><br>
 Pwd : <input type="password" name="pwd" required><br><br>
  <input type="submit" name="logged_in"><br>
  </form>
  
 <a href="<?php echo base_url();?>logged/register"  > <h2>Register</h2></a>
</div>
</body>

</html>