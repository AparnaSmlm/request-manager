<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="<?php echo base_url();?>home/dashboard">Dashboard</a>
  <a href="<?php echo base_url();?>home/userlist">User List</a>
  <a href="<?php echo base_url();?>home/friendlist">Friends List</a>
  <a href="<?php echo base_url();?>home/editprofile">Profile</a>
  <a href="<?php echo base_url();?>logged/out">Logout</a>
</div>
