<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="<?php echo base_url()?>assets/css/style.css"> 
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
<?php  $this->view("sidebar");?>

<div id="main">
  <!--<h2>User Panel</h2>-->
   <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; </span>
   
  
  <h2>User List</h2>

<table>
 
	   
	   <tr>
    <th>Name</th>
    <th>Email</th>
    <th>Gender</th>
    <th>Action</th>
  </tr>
   <?php  $resultq='';$status='';
   $myid = $this->session->userdata('user_id');
   foreach($res->result() as $row)
   { if($myid!==$row->id){
	   ?>
  <tr>
     <td><img src="<?php echo base_url();?>assets/image/<?php echo $row->pic;?>" width="50" height="50" /> <?php echo $row->name;?></td>
    <td><?php echo $row->email;?></td>
    <td><?php echo $row->gender;?></td>
	 <td><?php      
//check frnd or not
  

$query=$this->db->query("SELECT status
FROM friendslist
WHERE (sender_id = '$myid' AND receiver_id = '$row->id')
OR (receiver_id = '$myid' AND sender_id = '$row->id')");
if($query->num_rows()==0){
$resultq=0; $status='Add Friend';} //not frnd 
else {	 foreach($query->result() as $rows){
					 $statusd = $rows->status;
	 }	if($statusd==3){	$resultq=3; $status='Unfriend';}//frnd
}
 
$query=$this->db->query("SELECT status
FROM friendslist
WHERE (sender_id = '$myid' AND receiver_id = '$row->id')");
if($query->num_rows()==1){
	 foreach($query->result() as $rows){
					 $statusd = $rows->status;
				 }	
		if($statusd==1){		$resultq=1;$status='Cancel Request';// cancel
		}
 }
 
$query=$this->db->query("SELECT status
FROM friendslist
WHERE (sender_id = '$row->id' AND receiver_id = '$myid')");
if($query->num_rows()==1){
	 foreach($query->result() as $rows){
					 $statusd = $rows->status;
				 }	
		if($statusd==1){			$resultq=2;$status='Respond to request';//accept (respond)  
		}

} 

 ?> <button id="<?php echo $row->id;?>" value="<?php echo $resultq;?>" ><?php echo $status?></button></td>
   
  </tr>
   <?php }} ?>
</table>
</div>

<script>

$("button").click(function() {

 var value=$(this).attr("value");	 
  var id=$(this).attr("id");	 
	                  		 
$.ajax({
                type:'POST',
                url:'<?php echo base_url("home/actionhandler"); ?>',
                data:{'id':id,'status':value},
                success:function(data){
                  				 
								// alert(data);
    $('#'+id+'').html(data);
                 }
            });
			
		 
 });


function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
}
</script>
   
</body>
</html> 
