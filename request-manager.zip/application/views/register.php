<style>.container {
  width: 500px;
 }

.container input {
  width: 100%;
    height:5%

 }
</style>
<html>

<head>
  <title>Register</title>
</head>

<body>



<h2>Register</h2><br>
<?php if($this->session->flashdata('message')!='') {echo $this->session->flashdata('message');}?>
<div class="container">
<form method="post" action="<?php echo base_url();?>logged/registerform" enctype="multipart/form-data">
 Name : <input type="text" name="name" required ><br>
Email : <input type="email" name="email" required><br>
Profile pic : <input type="file" name="pic" required><br>
Gender : 
<input style=" width: 20%;" type="radio" name="gender" value="male"/>Male
<input style=" width: 20%;"type="radio" name="gender" value="Female"/>Female<br>
 Pwd : <input type="password" name="pwd" required><br><br>
  <input type="submit" name="submit"><br>
  </form>
  

</div>
</body>

</html>