<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin_model extends CI_Model {
	var $_date = '654+6';
	function __construct() {
		parent::__construct();
		$this->_date = date("Y-m-d");
	}
 
	function add_with_check($data,$table,$check) {
		$res = $this->totalcount($table, $check);
		if ($res == 0) {
		
			//$data['ok']=true;

			$data = $this->add_data($data,$table);
		}	
		else {
				$data['ok']=false;
			$data['resultmsg'] = '<div class="alert alert-danger">Sorry, already exist</div>';	
		}	
			return $data;	
		}
		function totalcount($table, $where){
			$this->db->where($where);
			$res = $this->db->get($table);
			$total_rows = $res->num_rows();
			return $total_rows;
		}
		protected function add_data($data,$table){	
			
				$data['entry_date'] = $this->_date;	
				if(!isset($data['status'])) {
					$data['status'] = 1;
				}
			
			if($this->insert_to($table, $data)){
				foreach($data as $key =>$val){
					$data[$key] = '';
				}
				unset($_POST);
				$data['timeout'] = true;
				$data['time_out'] = true;
				$data['resultmsg'] = '<div class="alert alert-success">Added Successfully</div>';
				$data['ok']=true;
			}
			else{
				$data['resultmsg'] = '<div class="alert alert-danger">Try again..</div>';
			}
			return $data;
		}	
		function insert_to($table, $data){
			$data = $this->security->xss_clean($data);	
			if($this->db->insert($table, $data)){
				return true;
			}
			return false;
		} 

	function get_where_from($where,$table,$field) {
			$this->db->select($field);
			$query = $this->db->get_where($table, $where);
			$data=$query->result();
 		 
		// echo $this->db->last_query();exit;
		return $query;
	}
	function get_all_data($table){
	$this->db->select('*');
	$this->db->from($table);
	$this->db->order_by('id','DESC');
	$query=$this->db->get(); 
	return $data = $query->result(); 
	}
	
public function delete_id_table($table,$where)
{

	$this->db->where($where);
	if($this->db->delete($table))
	{
		$this->session->set_flashdata('result_msg', '<div class="alert alert-success fade in"><a href="" class="close" data-dismiss="alert">&times;</a>Successfully Deleted</div>  ');
	}
	
 return;
}
	function edit_with_check($data,$where,$table,$check) {
		$res = $this->totalcount($table, $check);
		if ($res == 0) {
			$data = $this->edit_data($data,$table,$where);
		}
		else {
			$data['resultmsg'] = '<h4 class="alert_error">Sorry, already exist</h4>';
		}
		return $data;
	}
	
	
	public function edit_data($data,$table,$where) { 
		if($this->update_value($table,$where,$data)) { 
			$data['resultmsg'] = '<h4 class="alert_success">Updated Successfully</h4>';
			$data['timeout'] = true;
		}
		else {
			$data['resultmsg'] = '<h4 class="alert_error">Try again..</h4>';
		}
		return $data;
	}
	
	function update_value($table,$where,$data) {
		$data = $this->security->xss_clean($data);
		if($this->db->update($table, $data, $where)) {
			return true;
		}
		else
		return false;
	}
	
	function jointable($mid) {
		
		
		$send=array(); 
		$receive=array(); 
	$this->db->select('friendslist.sender_id,friendslist.receiver_id'); 
$this->db->from('friendslist');
$this->db->join('register t2_1', 't2_1.id = friendslist.sender_id', 'right'); 
$this->db->join('register t2_2', 't2_2.id = friendslist.receiver_id', 'right'); 
   $this->db->where("friendslist.sender_id='$mid' or friendslist.receiver_id='$mid'   ");
$query=$this->db->get();  //echo $this->db->last_query();exit;
 foreach($query->result() as $row)
 {
	   $send[]=$row->sender_id;
	   $receive[]=$row->receiver_id;
 }
 $resu=array_unique(array_merge($send,$receive)); //print_r(array_merge($send,$receive));exit;
 if (($key = array_search($mid, $resu)) !== false) {
    unset($resu[$key]);
} 

	return $resu; 
	}
	
}