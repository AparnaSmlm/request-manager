<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Loggedin extends CI_Model {
	var $_date = '';
	function __construct() {
		parent::__construct();
		$this->load->library('session');
 	}
	function validateadmin($data,$table) {
	  	$data['password'] = hash("sha256", $data['password']); 
  		$sql="select id,email,password from $table where email=".$this->db->escape($data['email'])." and status = 1 and password=".$this->db->escape($data['password']);
		$res=$this->db->query($sql);
		if ($res->num_rows() > 0) {
			foreach ($res->result() as $row) {			
				if($row->password== $data['password']) {
					$loggeddata = array(
    					'user_id'  => $row->id,
   						'username'     => $row->email,
   						'userlogged' => TRUE
   					);
 					$this->session->set_userdata($loggeddata);
 					return true;
				}
			}
		}
		$this->session->set_flashdata('error_message', '<h4 class="alert_error">The username or password is incorrect</h4>');
		return false;
	}
}